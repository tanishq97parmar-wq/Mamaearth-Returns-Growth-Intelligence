from pathlib import Path
import json, sqlite3
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "analysis"
NARRATOR = ROOT / "narrator"
OUT.mkdir(exist_ok=True)
NARRATOR.mkdir(exist_ok=True)

customers = pd.read_csv(DATA / "customers.csv")
products = pd.read_csv(DATA / "products.csv")
orders = pd.read_csv(DATA / "orders.csv")

print("TASK 1 — LOAD & INSPECT")
print("customers.shape:", customers.shape)
print("products.shape:", products.shape)
print("orders.shape:", orders.shape)  # Expected (180, 9)

print("\nTASK 2 — PAYMENT METHOD BEFORE CLEANING")
print(orders["payment_method"].unique())
orders["payment_method"] = orders["payment_method"].str.strip().str.upper()
print("After standardization counts:")
print(orders["payment_method"].value_counts().to_dict())

print("\nTASK 3 — DUPLICATE ORDERS")
natural_key = ["customer_id","product_id","order_date","quantity","discount_pct","payment_method","rating","returned"]
dup_mask = orders.duplicated(subset=natural_key, keep="first")
dropped = orders.loc[dup_mask].copy()
print("Duplicate rows flagged:", int(dup_mask.sum()))
print("Dropped order IDs:", sorted(dropped["order_id"].tolist()))
orders_clean = orders.loc[~dup_mask].copy()
print("orders_clean.shape:", orders_clean.shape)

print("\nTASK 4 — MISSING VALUE IMPUTATION")
missing_discount = int(orders_clean["discount_pct"].isna().sum())
orders_clean["discount_pct"] = orders_clean["discount_pct"].fillna(0)
median_rating = float(orders_clean["rating"].median())
missing_rating = int(orders_clean["rating"].isna().sum())
print("Missing discount_pct filled with 0:", missing_discount)
print("Median rating before imputation:", median_rating)
print("Missing rating values filled:", missing_rating)
orders_clean["rating"] = orders_clean["rating"].fillna(median_rating)
print("Missing after imputation:", orders_clean[["discount_pct","rating"]].isnull().sum().to_dict())

print("\nTASK 5 — MERGE & RECONCILE")
merged = orders_clean.merge(products, on="product_id", how="left", validate="many_to_one")
merged = merged.merge(customers, on="customer_id", how="left", validate="many_to_one")
merged["order_value"] = merged["quantity"] * merged["price"] * (1 - merged["discount_pct"] / 100)
cleaned_total = round(float(merged["order_value"].sum()), 2)
# Independently calculate dropped rows' value using the original product lookup and null discount as zero.
dropped = dropped.merge(products[["product_id","price"]], on="product_id", how="left", validate="many_to_one")
dropped["discount_pct"] = dropped["discount_pct"].fillna(0)
dropped["order_value"] = dropped["quantity"] * dropped["price"] * (1 - dropped["discount_pct"] / 100)
delta = round(float(dropped["order_value"].sum()), 2)
raw = pd.read_csv(DATA / "orders.csv")
raw = raw.merge(products[["product_id","price"]], on="product_id", how="left")
raw["discount_pct"] = raw["discount_pct"].fillna(0)
raw_total = round(float((raw["quantity"] * raw["price"] * (1 - raw["discount_pct"]/100)).sum()), 2)
print("Cleaned merged shape:", merged.shape)
print(f"Cleaned total revenue: ₹{cleaned_total:,.2f}")
print(f"Raw total revenue: ₹{raw_total:,.2f}")
print(f"Duplicate reconciliation delta: ₹{delta:,.2f}")
print(f"Reconciliation note: Raw revenue ₹{raw_total:,.2f} minus cleaned revenue ₹{cleaned_total:,.2f} equals ₹{delta:,.2f}; this exact difference is explained by the 5 duplicate rows removed ({', '.join(sorted(dropped['order_id'].tolist()))}). Discount and rating imputation does not change order_value total.")

print("\nTASK 6 — IQR OUTLIERS ON QUANTITY")
q1 = float(merged["quantity"].quantile(.25))
q3 = float(merged["quantity"].quantile(.75))
iqr = q3 - q1
lower, upper = q1 - 1.5*iqr, q3 + 1.5*iqr
merged["is_outlier"] = ~merged["quantity"].between(lower, upper)
print(f"Q1={q1:.1f}, Q3={q3:.1f}, IQR={iqr:.1f}, lower={lower:.1f}, upper={upper:.1f}")
print("Outlier orders:", merged.loc[merged["is_outlier"], ["order_id","quantity"]].to_dict("records"))

print("\nTASK 7 — COD RETURN RATE HYPOTHESIS")
print("Hypothesis: COD orders have a higher return rate than CARD and UPI.")
payment_rates = merged.groupby("payment_method")["returned"].agg(["count","mean"])
payment_rates["return_rate_pct"] = (payment_rates["mean"] * 100).round(1)
print(payment_rates[["count","return_rate_pct"]])
cod_rate = float(payment_rates.loc["COD","return_rate_pct"])
print("Hypothesis:", "Confirmed" if cod_rate > max(payment_rates.drop(index="COD")["return_rate_pct"]) else "Not confirmed")

print("\nTASK 8 — PAYMENT METHOD × CITY TIER SEGMENTATION")
segments = merged.groupby(["payment_method","city_tier"])["returned"].agg(["count","mean"]).reset_index()
segments["return_rate_pct"] = (segments["mean"]*100).round(1)
print(segments[["payment_method","city_tier","count","return_rate_pct"]].to_string(index=False))
highest = segments.sort_values(["return_rate_pct","count"], ascending=[False,False]).iloc[0]
print(f"Highest-risk segment: {highest['payment_method']} + Tier-{int(highest['city_tier'])} at {highest['return_rate_pct']:.1f}%")

print("\nTASK 9 — CORRELATION ANALYSIS")
corr_cols = ["rating","returned","discount_pct","quantity"]
corr = merged[corr_cols].corr(numeric_only=True)
print(corr.round(3))
def band(v):
    a = abs(float(v))
    if a < .2: return "negligible"
    if a < .4: return "weak"
    if a < .7: return "moderate"
    return "strong"
for i, a in enumerate(corr_cols):
    for b in corr_cols[i+1:]:
        value = float(corr.loc[a,b])
        print(f"{a} vs {b}: r={value:.3f} — {band(value)}")
discount_corr = float(corr.loc["discount_pct","returned"])
print("Hypothesis 'higher discounts reduce returns':", "Busted" if abs(discount_corr) < .2 else "Needs further investigation")

print("\nTASK 10 — MONTHLY REVENUE, INCLUDING AND EXCLUDING OUTLIERS")
merged["order_date"] = pd.to_datetime(merged["order_date"])
merged["month"] = merged["order_date"].dt.to_period("M").astype(str)
monthly_all = merged.groupby("month")["order_value"].sum().round(2)
monthly_corrected = merged.loc[~merged["is_outlier"]].groupby("month")["order_value"].sum().round(2)
print("Including outliers:")
print(monthly_all.to_string())
print("Excluding outliers:")
print(monthly_corrected.to_string())
peak = monthly_corrected.idxmax()
print(f"Interpretation: January's apparent lead is an artifact of bulk orders O0011 (2026-01-28) and O0098 (2026-01-10). March is the genuine peak month after excluding these two outliers: ₹{monthly_corrected[peak]:,.2f}.")

# Save stable intermediate artifacts for the visualization and narrator layers.
merged.to_csv(OUT / "cleaned_merged_orders.csv", index=False)
payment_rates[["count","return_rate_pct"]].to_csv(OUT / "return_rates.csv")
monthly_corrected.rename("revenue_inr").to_csv(OUT / "monthly_revenue_corrected.csv")
monthly_all.rename("revenue_inr").to_csv(OUT / "monthly_revenue_including_outliers.csv")

findings = {
    "cleaned_total_revenue_inr": cleaned_total,
    "raw_total_revenue_inr": raw_total,
    "duplicate_reconciliation_delta_inr": delta,
    "return_rate_by_payment": {k: float(v) for k,v in payment_rates["return_rate_pct"].to_dict().items()},
    "highest_risk_segment": {
        "payment_method": str(highest["payment_method"]),
        "city_tier": int(highest["city_tier"]),
        "return_rate_pct": float(highest["return_rate_pct"])
    },
    "true_peak_month": {"month": str(peak), "revenue_inr": round(float(monthly_corrected[peak]),2)},
    "outlier_inflated_month": {
        "month": str(monthly_all.idxmax()),
        "apparent_revenue_inr": round(float(monthly_all.max()),2),
        "corrected_revenue_inr": round(float(monthly_corrected.loc[monthly_all.idxmax()]),2)
    }
}
(NARRATOR / "findings.json").write_text(json.dumps(findings, indent=2), encoding="utf-8")
print("\nfindings.json written from computed analysis values.")
