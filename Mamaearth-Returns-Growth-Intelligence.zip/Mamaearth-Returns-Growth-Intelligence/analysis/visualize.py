from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "visualizations"
ANALYSIS = ROOT / "analysis"
OUT.mkdir(exist_ok=True)

rates = pd.read_csv(ANALYSIS / "return_rates.csv", index_col=0).sort_values("return_rate_pct", ascending=False)
fig, ax = plt.subplots(figsize=(8,5))
bars = ax.bar(rates.index, rates["return_rate_pct"])
ax.set_ylabel("Return rate (%)")
ax.set_xlabel("Payment method")
ax.set_title("COD Returns at 44.4% — Highest of All Payment Methods")
ax.set_ylim(0, max(rates["return_rate_pct"])*1.25)
for bar, value in zip(bars, rates["return_rate_pct"]):
    ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+0.8, f"{value:.1f}%", ha="center")
fig.tight_layout()
fig.savefig(OUT / "return_rate_by_payment.png", dpi=160)
plt.close(fig)

monthly = pd.read_csv(ANALYSIS / "monthly_revenue_corrected.csv")
fig, ax = plt.subplots(figsize=(9,5))
ax.plot(monthly["month"], monthly["revenue_inr"], marker="o")
ax.set_xlabel("Month")
ax.set_ylabel("Outlier-corrected revenue (INR)")
ax.set_title("Outlier-Corrected Monthly Revenue — Peak: March 2026")
ax.tick_params(axis="x", rotation=30)
fig.tight_layout()
fig.savefig(OUT / "monthly_revenue_trend.png", dpi=160)
plt.close(fig)
print("Saved visualizations/return_rate_by_payment.png")
print("Saved visualizations/monthly_revenue_trend.png")
