from pathlib import Path
import json, os, re

ROOT = Path(__file__).resolve().parents[1]
FINDINGS_PATH = ROOT / "narrator" / "findings.json"
SAMPLE_PATH = ROOT / "narrator" / "sample_output.txt"

def generate_scr_narrative_offline(findings: dict) -> dict:
    rates = findings["return_rate_by_payment"]
    risk = findings["highest_risk_segment"]
    peak = findings["true_peak_month"]
    inflated = findings["outlier_inflated_month"]
    delta = findings["duplicate_reconciliation_delta_inr"]
    cleaned = findings["cleaned_total_revenue_inr"]
    cod = rates["COD"]
    card = rates["CARD"]
    upi = rates["UPI"]
    narrative = f"""Situation
The cleaned order analysis records ₹{cleaned:,.2f} in revenue across the deduplicated order set. The raw-data comparison is ₹{findings['raw_total_revenue_inr']:,.2f}, providing a clear reconciliation baseline for finance and operations.

Complication
Returns are concentrated in Cash on Delivery (COD): its return rate is {cod:.1f}%, compared with {card:.1f}% for CARD and {upi:.1f}% for UPI. The highest-risk segment is COD in Tier-{risk['city_tier']} cities, with a {risk['return_rate_pct']:.1f}% return rate. The raw-to-cleaned revenue difference is ₹{delta:,.2f}, attributable to the five duplicate orders removed during cleaning. January appears to lead at ₹{inflated['apparent_revenue_inr']:,.2f} before outlier correction, but its corrected revenue is ₹{inflated['corrected_revenue_inr']:,.2f}.

Resolution
Prioritize a COD-focused operational review in Tier-{risk['city_tier']} cities: examine confirmation, delivery, and return reasons before changing payment policy. Use the cleaned, outlier-corrected monthly series for planning; March 2026 ({peak['month']}) is the true peak month at ₹{peak['revenue_inr']:,.2f}. Keep the duplicate-reconciliation check in the repeatable pipeline so reported revenue remains auditable. These are synthetic teaching data, so validate proposed actions against approved business data before implementation."""
    return {"status":"success", "narrative":narrative, "tokens":None, "mode":"offline"}

def generate_scr_narrative(findings: dict) -> dict:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return generate_scr_narrative_offline(findings)
    try:
        from google import genai
        from google.genai import types
        client = genai.Client(api_key=api_key, http_options=types.HttpOptions(timeout=20000))
        system_instruction = (
            "You are a senior data analyst writing for Mamaearth's regional ops and finance heads. "
            "Use exactly three labeled sections: Situation, Complication, Resolution. "
            "Every number must come only from the supplied findings and retain the same value; "
            "do not invent statistics. Keep it actionable and concise."
        )
        prompt = "Write an SCR business narrative from this verified findings JSON. Do not introduce any numbers not present in the findings:\n" + json.dumps(findings, indent=2)
        # Temperature 0.0 is used because this is a factual report and reproducibility matters more than creativity.
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=0.0,
                max_output_tokens=600
            )
        )
        return {"status":"success", "narrative":response.text, "tokens":getattr(getattr(response,"usage_metadata",None),"total_token_count",None), "mode":"gemini"}
    except Exception as err:
        offline = generate_scr_narrative_offline(findings)
        offline["fallback_reason"] = str(err)
        return offline

def check_numeric_accuracy(narrative: str) -> bool:
    normalized = narrative.replace(",", "")
    checks = {
        "cleaned revenue 97358.30": ["97358.30", "97358.3"],
        "COD return rate 44.4": ["44.4"],
        "COD Tier-2 risk 54.5": ["54.5"],
        "duplicate delta 2501.90": ["2501.90", "2501.9"],
        "March peak 20318.90": ["March", "20318.90"],
    }
    all_ok = True
    for label, parts in checks.items():
        ok = all(part.lower() in normalized.lower() for part in parts)
        print(f"{'PASS' if ok else 'FAIL'} — {label}")
        all_ok = all_ok and ok
    return all_ok

def main():
    findings = json.loads(FINDINGS_PATH.read_text(encoding="utf-8"))
    result = generate_scr_narrative(findings)
    if not result.get("narrative"):
        result = generate_scr_narrative_offline(findings)
    print("Narrative mode:", result.get("mode", result["status"]))
    print(result["narrative"])
    print("\nNUMERIC ACCURACY CHECK")
    passed = check_numeric_accuracy(result["narrative"])
    SAMPLE_PATH.write_text(result["narrative"] + "\n", encoding="utf-8")
    print("Saved narrator/sample_output.txt")
    if not passed:
        raise SystemExit("Numeric accuracy checker failed.")
    print("All numeric accuracy checks passed.")

if __name__ == "__main__":
    main()
